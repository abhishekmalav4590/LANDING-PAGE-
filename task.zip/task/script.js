// Task data structure
const tasks = [];

// Add task form submission handler
document.getElementById('add-task-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const title = document.getElementById('task-title').value;
  const deadline = document.getElementById('task-deadline').value;
  const priority = document.getElementById('task-priority').value;
  const labels = document.getElementById('task-labels').value.split(',');
  tasks.push({
    id: tasks.length + 1,
    title,
    deadline,
    priority,
    labels,
    completed: false
  });
  renderTaskList();
  document.getElementById('task-title').value = '';
  document.getElementById('task-deadline').value = '';
  document.getElementById('task-priority').value = 'low';
  document.getElementById('task-labels').value = '';
});

// Render task list
function renderTaskList() {
  const taskListContainer = document.getElementById('task-list');
  taskListContainer.innerHTML = '';
  tasks.forEach((task) => {
    const taskTemplate = document.getElementById('task-template');
    const taskHTML = taskTemplate.innerHTML.replace(/{{id}}/g, task.id)
      .replace(/{{title}}/g, task.title)
      .replace(/{{deadline}}/g, task.deadline)
      .replace(/{{priority}}/g, task.priority)
      .replace(/{{labels}}/g, task.labels.join(', '));
    taskListContainer.innerHTML += taskHTML;
  });
}

// Update task completion status
document.getElementById('task-list').addEventListener('click', (e) => {
  if (e.target.type === 'checkbox') {
    const taskId = e.target.id.replace('task-', '');
    const task = tasks.find((task) => task.id === parseInt(taskId));
    task.completed = e.target.checked;
    updateProgressBar();
  }
});

// Update progress bar
function updateProgressBar() {
  const completedTasks = tasks.filter((task) => task.completed);
  const progress = (completedTasks.length / tasks.length) * 100;
  document.getElementById('progress-bar-inner').style.width = `${progress}%`;
}

// Initialize task list
renderTaskList();